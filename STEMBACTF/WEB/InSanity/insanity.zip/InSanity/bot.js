import puppeteer from 'puppeteer';

export const visit = (id) => {
  return new Promise(async (resolve, reject) => {
    try {
      const browser = await puppeteer.launch({
        headless: true,
        pipe: true,
        args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage'],

      });
      const incognito = await browser.createIncognitoBrowserContext();
      const page = await incognito.newPage();
      await page.setCookie({ name: 'flag', value: process.env.FLAG || 'STEMBACTF{fake_flag_bro_awas_jangan_disubmit!}', domain: 'localhost' });
      await page.goto(`http://localhost:3000/craft/${id}`);
      await page.waitForNetworkIdle({ timeout: 5000 });
      await page.close();
      await incognito.close();
      await browser.close();
      resolve();
    } catch (e) {
      reject(e);
    }
  });
};
