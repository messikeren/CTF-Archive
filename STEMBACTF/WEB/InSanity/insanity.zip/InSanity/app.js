import path from "node:path";
import express from "express";
import { nanoid } from 'nanoid';
import { marked } from 'marked';

import { db, init } from "./db.js";
import { visit } from './bot.js';

const app = express();

app.use(express.static(path.resolve('public')));
app.use(express.urlencoded({ extended: false }));

app.set('view engine', 'ejs');
app.set('views', path.resolve('views'));

app.get('/', (req, res) => {
  res.render('pages/home');
});

app.post('/crafting', (req, res) => {
  const { title, content } = req.body;
  const id = nanoid(12);

  const markedContent = marked.parse(content, { mangle: false, headerIds: false });

  db.serialize(() => {
    db.run('INSERT INTO crafts VALUES (?, ?, ?)', [id, title, markedContent], (err) => {
      if (err) {
        console.log(err);
        return res.sendStatus(500);
      };
      res.redirect(`/craft/${id}`);
    });
  });
});

app.get('/craft/:id', (req, res) => {
  db.get('SELECT * FROM crafts WHERE id = ?', [req.params.id], (err, row) => {
    if (err) {
      console.log(err);
      return res.sendStatus(500);
    };

    if (!row) return res.sendStatus(404);

    res.render('pages/craft', {
      craft: {
        id: row.id,
        title: encodeURIComponent(row.title),
        content: encodeURIComponent(row.content)
      }
    });
  });
});

app.get('/report/:id', (req, res) => {
  visit(req.params.id)
    .then(() => {
      res.status(200).send('Reported!');
    })
    .catch((err) => {
      console.log(err);
      res.status(500).send('Failed to report!');
    });
});

app.listen(3000, '0.0.0.0', () => {
  init();
  console.log('App started 🚀');
});