class Parser {
  #sanitize;
  constructor(sanitize = true) {
    this.#sanitize = sanitize;
  }

  get sanitize() {
    return this.#sanitize;
  }
}

function renderTitle(title) {
  const sanitizer = new Sanitizer();
  document.getElementById('title').setHTML(decodeURIComponent(title), { sanitizer });
}

async function renderContent(content) {
  const sanitizer = new Sanitizer();

  let options = null;

  if (window.parser?.options) {
    let res = await fetch(window.parser.options.toString());
    options = await res.json();
  }

  let parser = new Parser();
  parser = Object.assign(parser, options ?? { report: true });

  const renderedContent = decodeURIComponent(content);

  if (!parser.report) {
    document.getElementById('report').remove();
  }

  if (parser.sanitize) {
    document.getElementById('content').setHTML(renderedContent, { sanitizer });
  } else {
    document.getElementById('content').innerHTML = renderedContent;
  }
}