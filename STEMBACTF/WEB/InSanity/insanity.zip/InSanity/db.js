import sqlite3 from 'sqlite3';

export const db = new sqlite3.Database(':memory:', (err) => {
  if (err) {
    console.error('Database not connected!');
    process.exit(1);
  }

  console.log('Database connected!');
});

export const init = () => {
  db.serialize(() => {
    db.run('DROP TABLE IF EXISTS crafts');
    db.run('CREATE TABLE crafts (id VARCHAR(255) PRIMARY KEY, title VARCHAR(255), content TEXT)');
  });
};